var rainbowEnable = false;
var randomEnable = false; 
var lightshow; 
var run;
var run2;
var run3;
var run4; 
var connection = new WebSocket('ws://'+location.hostname+':81/', ['arduino']);
var interval; 
connection.onopen = function () {
    connection.send('Connect ' + new Date());
};
connection.onerror = function (error) {
    console.log('WebSocket Error ', error);
};
connection.onmessage = function (e) {  
    console.log('Server: ', e.data);
};
connection.onclose = function(){
    console.log('WebSocket connection closed');
};

function sendRGB() {
    var r = document.getElementById('r').value**2/1023;
    var g = document.getElementById('g').value**2/1023;
    var b = document.getElementById('b').value**2/1023;
    
    var rgb = r << 20 | g << 10 | b;
    var rgbstr = '#'+ rgb.toString(16);    
    console.log('RGB: ' + rgbstr); 
    connection.send(rgbstr);
}

function rainbowEffect(){
    rainbowEnable = ! rainbowEnable;
    if(rainbowEnable){
        connection.send("R");
        document.getElementById('rainbow').style.backgroundColor = '#00878F';
        document.getElementById('r').className = 'disabled';
        document.getElementById('g').className = 'disabled';
        document.getElementById('b').className = 'disabled';
        document.getElementById('r').disabled = true;
        document.getElementById('g').disabled = true;
        document.getElementById('b').disabled = true;
    } else {
        connection.send("N");
        document.getElementById('rainbow').style.backgroundColor = '#999';
        document.getElementById('r').className = 'enabled';
        document.getElementById('g').className = 'enabled';
        document.getElementById('b').className = 'enabled';
        document.getElementById('r').disabled = false;
        document.getElementById('g').disabled = false;
        document.getElementById('b').disabled = false;
        sendRGB();
    }  
}

function toggleRed(){
document.getElementById('r').value=1023; 
sendRGB();
}

function toggleGreen(){
document.getElementById('g').value=1023; 
sendRGB();
}

function toggleBlue(){
document.getElementById('b').value=1023; 
sendRGB();
}

function resetThis(){
document.getElementById('r').value=0; 
document.getElementById('g').value=0; 
document.getElementById('b').value=0;
 sendRGB();
  
}

function random(){
var min = 0; 
var max = 1023; 
document.getElementById('r').value=Math.floor(Math.random()*(max-min+1)+min);
document.getElementById('g').value=Math.floor(Math.random()*(max-min+1)+min);
document.getElementById('b').value=Math.floor(Math.random()*(max-min+1)+min);
sendRGB();
}


function lights(){ 
randomEnable=! randomEnable;
if(!randomEnable){
connection.send("A");
document.getElementById('lightshow').style.backgroundColor = '#999';
stopFunction();
resetThis();
	}
	
	else {
connection.send("B");
document.getElementById('lightshow').style.backgroundColor = '#00878F';
run = setTimeout("toggleGreen()", 500);
run2 = setTimeout("toggleRed()", 1000);
run3 = setTimeout("toggleBlue()", 1500);
run4 = setTimeout("resetThis()", 2000);
lightshow = setInterval("random()", 2500)
}

}

function stopFunction(){
	clearInterval(lightshow);
	clearTimeout(run);
	clearTimeout(run2);
	clearTimeout(run3);
	clearTimeout(run4);
}

/*
var letters = ["r", "g", "b",];
var combi = [];
var temp= "";
var letLen = Math.pow(2, letters.length);

for (var i = 0; i < letLen ; i++){
    temp= "";
    for (var j=0;j<letters.length;j++) {
        if ((i & Math.pow(2,j))){ 
            temp += letters[j]
        }
    }
    if (temp !== "") {
        combi.push(temp);
    }
	}
}
	/*
	for(var k = 0; k<combi.length; k++){
		if(combi[k].includes("r"){
			toggleRed();
		}
		if(combi[k].includes("g"){
			toggleBlue();
		}
	    if(combi[k].includes("b"){
			toggleGreen();
		}
		setTimeout(resetThis(), 3000);
	}
}  



/*
function playGame2(){
	var playing = true;
	var min = 0; 
	var max = 2; 
	var num; 
	var i; 
	var duration = 2;
	var arr = [-1];
	var userArr= [duration+1];
	num = Math.floor(Math.random()*(max-min+1)+min);
	
	if(playing){
		
	for (i = 0; i < 20; i++) { 
	
	
	if(num==0){
	toggleRed();
	setTimeout(resetThis, 4000)
	arr[i]=0;
	}
	
	else if (num==1){
	toggleGreen();
	setTimeout(resetThis, 4000)
	arr[i]=1;
	}
	
	else if (num==2){
	toggleBlue();
	setTimeout(resetThis, 4000)
	arr[i]=2;
	}
	
	//if(userArr[i]==0)
		//duration++;
	//else{
		//duration=2;
		//resetThis();
		//playing = false; 
			num = Math.floor(Math.random()*(max-min+1)+min);
		if(i==5){
		playing = false; }
	}
	} 
	}
	

	*/


